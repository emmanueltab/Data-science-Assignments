## Fall 2025 Data Science workspace.
Use this repo for make your submissions.
Make sure to create a directory name as follows (depending on what homework is due) and pleace all your code in there:

- homework-1
- homework-2
..
etc.
